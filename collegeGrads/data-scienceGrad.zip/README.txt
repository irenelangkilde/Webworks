Personalization and Hosting Suggestions Document can be found at 
https://webworks.irenes-ventures.com/post-purchase--921ad30d-abee-40d0-a29e-363e44ba14bb

The password to access the page is: 1!2@thrEe#4$
