Prana PhotoArt static site

Replace images in assets/img/ with your own. Recommended filenames used by the template:
hero.jpg, about.jpg,
service-children.jpg, service-events.jpg, service-home.jpg, service-portraits.jpg,
why-camera.jpg, cta-wedding.jpg, reviewer.jpg,
work-01.jpg ... work-06.jpg

This site is plain HTML/CSS/JS and can be hosted on any static host.
